/**
 * 
 */
/**
 * 
 */
module LabBookingSystem {
	requires java.sql;
}