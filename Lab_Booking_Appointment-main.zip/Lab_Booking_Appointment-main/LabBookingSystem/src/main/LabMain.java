package main;

public class LabMain {
	public static void main(String[] args) {
		System.out.println("**********Welcome to Lab Appointment Booking System***********");
        MainMenu menu = new MainMenu();
        menu.login();
        menu.mainMenu();
    }

}
